#include "admin.h"
#include "ui_admin.h"
#include <stdio.h>
#include <cstring>
#include <QMessageBox>
using namespace std;
Admin::Admin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Admin)
{
    ui->setupUi(this);
}

Admin::~Admin()
{
    delete ui;
}
bool Admin::execAdmin()
{
    exec();
    return repeat;
}
//checks balance of all accounts
void Admin::on_balancebutton_clicked()
{
    QString t= ui->balancestand->text();
    char *p=(char *)malloc(100);
    QByteArray ba6=t.toLatin1();
    strcpy(p,ba6.data());
    int a=stoi(p);
    long int i=10000001;
    FILE* f;
    f=fopen("C:\\BMS\\latest_ac.txt\0","r");
    char latest[10];
    fgets(latest,10,f);
    fclose(f);
    latest[8]='\0';
    long int l=stoi(latest);
    char str[100]="C:\\BMS\\abcdefgh.txt\0";
    char op[1000];int ind=0;op[0]='\0';
    char balance[100];
    int temp;
    //checking all balances upto latest account
    for(;i<=l;i++)
    {
        sprintf(latest,"%ld",i);
        for(int i=0;i<8;i++)
        {
            str[i+7]=latest[i];
        }
        f=fopen(str,"r");
        if(f==NULL)
            continue;
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        temp=stoi(balance);
        if(temp>=a)
        {
            for(int k=0;k<8;k++)
            {
                op[ind]=latest[k];
                ind++;
            }
            op[ind]='\n';
            ind++;
            op[ind]='\0';
        }
    }
    QMessageBox msgBox;
    msgBox.setText(op);
    msgBox.exec();
}
//checks aadhaar number of all counts
void Admin::on_aadhaarbutton_clicked()
{
    QString t= ui->aadhaarstand->text();
    char *p=(char *)malloc(100);
    QByteArray ba6=t.toLatin1();
    strcpy(p,ba6.data());
    int a=stoi(p);
    long int i=10000001;
    FILE* f;
    f=fopen("C:\\BMS\\latest_ac.txt\0","r");
    char latest[10];
    fgets(latest,10,f);
    fclose(f);
    latest[8]='\0';
    long int l=stoi(latest);
    char str[100]="C:\\BMS\\abcdefgh.txt\0";
    char op[1000];int ind=0;op[0]='\0';
    char balance[100];
    long int temp;
    //checking all aadhaar numbers
    for(;i<=l;i++)
    {
        sprintf(latest,"%ld",i);
        for(int i=0;i<8;i++)
        {
            str[i+7]=latest[i];
        }
        f=fopen(str,"r");
        if(f==NULL)
            continue;
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        temp=stoi(balance);
        if(temp==a)
        {
            for(int k=0;k<8;k++)
            {
                op[ind]=latest[k];
                ind++;
            }
            op[ind]='\n';
            ind++;
            op[ind]='\0';
        }
    }
    QMessageBox msgBox;
    msgBox.setText(op);
    msgBox.exec();
}
//checks name on all accounts
void Admin::on_namebutton_clicked()
{
    QString t= ui->namestand->text();
    char *p=(char *)malloc(100);
    QByteArray ba6=t.toLatin1();
    strcpy(p,ba6.data());
    long int i=10000001;
    FILE* f;
    f=fopen("C:\\BMS\\latest_ac.txt\0","r");
    char latest[10];
    fgets(latest,10,f);
    fclose(f);
    latest[8]='\0';
    long int l=stoi(latest);
    char str[100]="C:\\BMS\\abcdefgh.txt\0";
    char op[1000];int ind=0;op[0]='\0';
    char balance[100];
    //checking name of all accounts
    for(;i<=l;i++)
    {
        sprintf(latest,"%ld",i);
        for(int i=0;i<8;i++)
        {
            str[i+7]=latest[i];
        }
        f=fopen(str,"r");
        if(f==NULL)
            continue;
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        fgets(balance,100,f);
        bool match=true;
        for(int k=0;k<100;k++)
        {
            if((p[k]=='\0' || p[k]=='\n') && (balance[k]=='\0' || balance[k]=='\n'))
                break;
            if(balance[k]!=p[k])
            {
                match=false;
                break;
            }
        }
        if(match==true)
        {
            for(int k=0;k<8;k++)
            {
                op[ind]=latest[k];
                ind++;
            }
            op[ind]='\n';
            ind++;
            op[ind]='\0';
        }
    }
    QMessageBox msgBox;
    msgBox.setText(op);
    msgBox.exec();
}

void Admin::on_closebutton_clicked()
{
    repeat=false;
    close();
}

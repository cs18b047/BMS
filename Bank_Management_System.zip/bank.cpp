#include "bank.h"
#include "ui_bank.h"
#include <iostream>
#include <cstring>
#include <QMessageBox>
using namespace std;
Bank::Bank(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Bank)
{
    ui->setupUi(this);
}

Bank::~Bank()
{
    delete ui;
}
void Bank::on_Loginbutton_clicked()
{
    QString name=ui->usernamebutton->text();
    QString pass=ui->passwordbutton->text();
    FILE* f;
    char *str=(char *)malloc(100);
    QByteArray ba=name.toLatin1();
    strcpy(str,ba.data());
    char str2[100]="C:\\BMS\\abcdefgh.txt\0";
    for(int i=0;i<8;i++)
    {
        str2[i+7]=str[i];
    }
    f=fopen(str2,"r");
    if(f==NULL)
    {
        QMessageBox msgBox;
        msgBox.setText("Invalid username");
        msgBox.exec();
        return;
    }
    char p[100];
    fgets(p,100,f);
    char *str1=(char *)malloc(100);
    QByteArray ba1=pass.toLatin1();
    strcpy(str1,ba1.data());
    bool match=true;
    for(int i=0;i<100;i++)
    {
        if((str1[i]=='\0' || str1[i]=='\n') && (p[i]=='\0' || p[i]=='\n'))
            break;
        if(str1[i]!=p[i])
        {
            match=false;
            break;
        }
    }
    if(match==false)
    {
        QMessageBox msgBox;
        msgBox.setText("Wrong password");
        msgBox.exec();
        return;
    }
    //code for user interface
    fclose(f);
    userobj=new User(this);
    hide();
    userobj->displayuser(str2);
    userobj->exec();
    show();
    return;
}

void Bank::on_signupbutton_clicked()
{
    //code for signup interface
    signupobj=new signup(this);
    hide();
    signupobj->show();
    signupobj->exec();
    show();
    return;
}

void Bank::on_forgotbutton_clicked()
{
    QString name=ui->usernamebutton->text();
    char *str=(char *)malloc(100);
    QByteArray ba=name.toLatin1();
    strcpy(str,ba.data());
    char str2[100]="C:\\BMS\\abcdefgh.txt\0";
    for(int i=0;i<8;i++)
    {
        str2[i+7]=str[i];
    }
    FILE* f;
    f=fopen(str2,"r");
    if(f==NULL)
    {
        QMessageBox msgBox;
        msgBox.setText("Invalid username");
        msgBox.exec();
        return;
    }
    fclose(f);
    forgotobj=new Forgot(this);
    hide();
    forgotobj->displayuser(str2);
    forgotobj->exec();
    show();
    return;
}

void Bank::on_Adminloginbutton_clicked()
{
    QString pass=ui->adminpass->text();
    char *str1=(char *)malloc(100);
    QByteArray ba=pass.toLatin1();
    strcpy(str1,ba.data());
    char str2[100]="C:\\BMS\\Admin_Pass.txt\0";
    FILE* f;
    f=fopen(str2,"r");
    char p[100];
    fgets(p,100,f);
    bool match=true;
    for(int i=0;i<100;i++)
    {
        if((str1[i]=='\0' || str1[i]=='\n') && (p[i]=='\0' || p[i]=='\n'))
            break;
        if(str1[i]!=p[i])
        {
            match=false;
            break;
        }
    }
    if(match==false)
    {
        QMessageBox msgBox;
        msgBox.setText("Wrong password");
        msgBox.exec();
        return;
    }
    hide();
    bool t=true;
    while(t)
    {
        t=OpenAdminInterface();
    }
    show();
    return;
}
bool Bank::OpenAdminInterface()
{
    Admin* adminob=new Admin();
    adminob->repeat=true;
    bool t=adminob->execAdmin();
    return t;
}

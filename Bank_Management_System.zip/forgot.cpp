#include "forgot.h"
#include "ui_forgot.h"
#include <stdio.h>
#include <QMessageBox>
Forgot::Forgot(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Forgot)
{
    ui->setupUi(this);
}

Forgot::~Forgot()
{
    delete ui;
}
void Forgot:: displayuser(char* str)
{
    for(int i=0;i<100;i++)
    {
        if(str[i]=='\0' || str[i]=='\n')
        {
            address[i]='\0';
            break;
        }
        address[i]=str[i];
    }
    return;
}
class UserDetails
{
    public:
    char pass[100],phno[100],mail[100],vid[100],aadhaar[100],name[100];
    char n[3],rc1[100],rc2[100],rc3[100],rc4[100],rc5[100],rc6[100];
    char acbal[100];
    void populate(FILE* &f)
    {
        fgets(pass,100,f);
        fgets(phno,100,f);
        fgets(mail,100,f);
        fgets(vid,100,f);
        fgets(aadhaar,100,f);
        fgets(name,100,f);
        fgets(acbal,100,f);
        fgets(n,100,f);
        if(n[0]=='1')
        {
        fgets(rc1,100,f);
        fgets(rc2,100,f);
        }
        if(n[0]=='2')
        {
        fgets(rc1,100,f);
        fgets(rc2,100,f);
        fgets(rc3,100,f);
        fgets(rc4,100,f);
        }
        if(n[0]=='3')
        {
        fgets(rc1,100,f);
        fgets(rc2,100,f);
        fgets(rc3,100,f);
        fgets(rc4,100,f);
        fgets(rc5,100,f);
        fgets(rc6,100,f);
        }
    }
    void StoreInFile(FILE* &f1)
    {
        fputs(phno,f1);
        fputs(phno,f1);
        fputs(mail,f1);
        fputs(vid,f1);
        fputs(aadhaar,f1);
        fputs(name,f1);
        fputs(acbal,f1);
        fputs(n,f1);
        if(n[0]=='1')
        {
        fputs(rc1,f1);
        fputs(rc2,f1);
        }
        if(n[0]=='2')
        {
        fputs(rc1,f1);
        fputs(rc2,f1);
        fputs(rc3,f1);
        fputs(rc4,f1);
        }
        if(n[0]=='3')
        {
        fputs(rc1,f1);
        fputs(rc2,f1);
        fputs(rc3,f1);
        fputs(rc4,f1);
        fputs(rc5,f1);
        fputs(rc6,f1);
        }
    }
};

void Forgot::on_pushButton_clicked()
{
    //accessing input information from ui
    QString qvid=ui->voteridbutton->text();
    QString qmail=ui->emailbutton->text();
    QString qadhar=ui->aadhaarbutton->text();
    char *vid=(char *)malloc(100);
    QByteArray ba1=qvid.toLatin1();
    strcpy(vid,ba1.data());
    char *mail=(char *)malloc(100);
    QByteArray ba2=qmail.toLatin1();
    strcpy(mail,ba2.data());
    char *adhar=(char *)malloc(100);
    QByteArray ba4=qadhar.toLatin1();
    strcpy(adhar,ba4.data());
    FILE* f;
    f=fopen(address,"r");
    UserDetails ob;
    ob.populate(f);
    fclose(f);
    bool match=true;
    //checking mail match
    for(int i=0;i<100;i++)
    {
        if((ob.mail[i]=='\0' || ob.mail[i]=='\n') && (mail[i]=='\0' || mail[i]=='\n'))
            break;
        if(ob.mail[i]!=mail[i])
        {
            match=false;
            break;
        }
    }
    //checking voter id match
    for(int i=0;i<100;i++)
    {
        if((ob.vid[i]=='\0' || ob.vid[i]=='\n') && (vid[i]=='\0' || vid[i]=='\n'))
            break;
        if(ob.vid[i]!=vid[i])
        {
            match=false;
            break;
        }
    }
    //checking aahaar match
    for(int i=0;i<100;i++)
    {
        if((ob.aadhaar[i]=='\0' || ob.aadhaar[i]=='\n') && (adhar[i]=='\0' || adhar[i]=='\n'))
            break;
        if(ob.aadhaar[i]!=adhar[i])
        {
            match=false;
            break;
        }
    }
    //if match is false
    if(match==false)
    {
        QMessageBox msgBox;
        msgBox.setText("Wrong Details");
        msgBox.exec();
        return;
    }
    //if match is true,overwriting password in corresponding txt file
    FILE* f1;
    f1=fopen(address,"w");
    ob.StoreInFile(f1);
    fclose(f1);
    QMessageBox msgBox;
    msgBox.setText("Password is reset to your phone number");
    msgBox.exec();
    return;
}

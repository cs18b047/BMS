#include "user.h"
#include "ui_user.h"
#include <stdio.h>
#include <QMessageBox>
using namespace std;
User::User(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::User)
{
    ui->setupUi(this);
}

User::~User()
{
    delete ui;
}
class USER
{
    public:
    char pass[100],phno[100],mail[100],vid[100],aadhaar[100],name[100];
    char n[3],rc1[100],rc2[100],rc3[100],rc4[100],rc5[100],rc6[100];
    char acbal[100];
    void Retreive(FILE* &f)
    {
        char buffer[100];
        fgets(buffer,100,f);
        strcpy(pass,buffer);
        fgets(buffer,100,f);
        strcpy(phno,buffer);
        fgets(buffer,100,f);
        strcpy(mail,buffer);
        fgets(buffer,100,f);
        strcpy(vid,buffer);
        fgets(buffer,100,f);
        strcpy(aadhaar,buffer);
        fgets(buffer,100,f);
        strcpy(name,buffer);
        fgets(buffer,100,f);
        strcpy(acbal,buffer);
        fgets(buffer,100,f);
        strcpy(n,buffer);
        n[1]='\n';
        n[2]='\0';
        char c=buffer[0];
        if(c=='0')
        {
            fclose(f);
        }
        if(c=='1')
        {
            fgets(buffer,100,f);
            strcpy(rc1,buffer);
            fgets(buffer,100,f);
            strcpy(rc2,buffer);
            fclose(f);
        }
        if(c=='2')
        {
            fgets(buffer,100,f);
            strcpy(rc1,buffer);
            fgets(buffer,100,f);
            strcpy(rc2,buffer);
            fgets(buffer,100,f);
            strcpy(rc3,buffer);
            fgets(buffer,100,f);
            strcpy(rc4,buffer);
            fclose(f);
        }
        if(c=='3')
        {
            fgets(buffer,100,f);
            strcpy(rc1,buffer);
            fgets(buffer,100,f);
            strcpy(rc2,buffer);
            fgets(buffer,100,f);
            strcpy(rc3,buffer);
            fgets(buffer,100,f);
            strcpy(rc4,buffer);
            fgets(buffer,100,f);
            strcpy(rc5,buffer);
            fgets(buffer,100,f);
            strcpy(rc6,buffer);
            fclose(f);
        }
    }
    void storeInFile(FILE* &f4)
    {
        fputs(pass,f4);
        fputs(phno,f4);
        fputs(mail,f4);
        fputs(vid,f4);
        fputs(aadhaar,f4);
        fputs(name,f4);
        fputs(acbal,f4);
        fputs(n,f4);
        if(n[0]=='1')
        {
        fputs(rc1,f4);
        fputs(rc2,f4);
        }
        if(n[0]=='2')
        {
        fputs(rc1,f4);
        fputs(rc2,f4);
        fputs(rc3,f4);
        fputs(rc4,f4);
        }
        if(n[0]=='3')
        {
        fputs(rc1,f4);
        fputs(rc2,f4);
        fputs(rc3,f4);
        fputs(rc4,f4);
        fputs(rc5,f4);
        fputs(rc6,f4);
        }
    }
};

void User::displayuser(char* str)
{
    FILE* f;
    for(int i=0;i<100;i++)
    {
        if(str[i]=='\0' || str[i]=='\n')
        {
            address[i]='\0';
            break;
        }
        address[i]=str[i];
    }
    f=fopen(address,"r");
    USER u;
    //retreiving user information from file
    u.Retreive(f);
    //to diplay the user information
    ui->phonenumberbutton->setText(u.phno);
    ui->emailbutton->setText(u.mail);
    ui->voteridbutton->setText(u.vid);
    ui->namebutton->setText(u.name);
    ui->balancebutton->setText(u.acbal);
    char ch=u.n[0];
    if(ch=='3')
    {
        ui->rc5->setText(u.rc5);
        ui->rc6->setText(u.rc6);
    }
    if(ch=='2' || ch=='3')
    {
        ui->rc3->setText(u.rc3);
        ui->rc4->setText(u.rc4);
    }
    if(ch=='1' || ch=='2' || ch=='3')
    {
        ui->rc1->setText(u.rc1);
        ui->rc2->setText(u.rc2);
    }
}


void User::on_pushButton_clicked()
{
    USER u;
    FILE* f;
    f=fopen(address,"r");
    u.Retreive(f);
    fclose(f);
    QString t= ui->currentpasswordbutton->text();
    char *p=(char *)malloc(100);
    QByteArray ba6=t.toLatin1();
    strcpy(p,ba6.data());
    //checking for password correctness
    bool match=true;
    for(int i=0;i<100;i++)
    {
        if((p[i]=='\0' || p[i]=='\n') && (u.pass[i]=='\0' || u.pass[i]=='\n'))
            break;
        if(u.pass[i]!=p[i])
        {
            match=false;
            break;
        }
    }
    if(match==false)
    {
        QMessageBox msgBox;
        msgBox.setText("Wrong password");
        msgBox.exec();
        return;
    }
    //updating password
    QString temp=ui->newpasswordbutton->text();
    char *str=(char *)malloc(100);
    QByteArray ba=temp.toLatin1();
    strcpy(str,ba.data());
    if(temp!=NULL)
    {
        for(int i=0;i<100;i++)
        {
            if(str[i]=='\0' || str[i]=='\n')
            {
                u.pass[i]='\n';
                u.pass[i+1]='\0';
                break;
            }
            u.pass[i]=str[i];
        }
    }
    //updating phone number
    QString temp1=ui->phonenumberbutton->text();
    char *str1=(char *)malloc(100);
    QByteArray ba1=temp1.toLatin1();
    strcpy(str1,ba1.data());
        for(int i=0;i<100;i++)
        {
            if(str1[i]=='\0' || str1[i]=='\n')
            {
                u.phno[i]='\n';
                u.phno[i+1]='\0';
                break;
            }
            u.phno[i]=str1[i];
        }
    //updating email
    QString temp2=ui->emailbutton->text();
    char *str2=(char *)malloc(100);
    QByteArray ba2=temp2.toLatin1();
    strcpy(str2,ba2.data());
        for(int i=0;i<100;i++)
        {
            if(str2[i]=='\0' || str2[i]=='\n')
            {
                u.mail[i]='\n';
                u.mail[i+1]='\0';
                break;
            }
            u.mail[i]=str2[i];
        }
    //updating voter id
    QString temp3=ui->voteridbutton->text();
    char *str3=(char *)malloc(100);
    QByteArray ba3=temp3.toLatin1();
    strcpy(str3,ba3.data());
        for(int i=0;i<100;i++)
        {
            if(str3[i]=='\0' || str3[i]=='\n')
            {
                u.vid[i]='\n';
                u.vid[i+1]='\0';
                break;
            }
            u.vid[i]=str3[i];
        }
    //updating name on account
    QString temp4=ui->namebutton->text();
    char *str4=(char *)malloc(100);
    QByteArray ba4=temp4.toLatin1();
    strcpy(str4,ba4.data());
        for(int i=0;i<100;i++)
        {
            if(str4[i]=='\0' || str4[i]=='\n')
            {
                u.name[i]='\n';
                u.name[i+1]='\0';
                break;
            }
            u.name[i]=str4[i];
        }
        //processing add money
        char addmoney[100];
        QString temp5=ui->addmoneybutton->text();
        char *str5=(char *)malloc(100);
        QByteArray ba5=temp5.toLatin1();
        strcpy(str5,ba5.data());
        if(temp5!=NULL)
        {
            for(int i=0;i<100;i++)
            {
                if(str5[i]=='\0' || str5[i]=='\n')
                {
                    addmoney[i]='\n';
                    addmoney[i+1]='\0';
                    break;
                }
                addmoney[i]=str5[i];
            }
            int addm;
            addm=stoi(addmoney);
            int curr;
            curr=stoi(u.acbal);
            curr=curr+addm;
            sprintf(u.acbal, "%d", curr);
            if(u.n[0]=='0')
                u.n[0]='1';
            else if(u.n[0]=='1')
                u.n[0]='2';
            else if(u.n[0]=='2')
                u.n[0]='3';
            strcpy(u.rc5,u.rc3);
            strcpy(u.rc6,u.rc4);
            strcpy(u.rc3,u.rc1);
            strcpy(u.rc4,u.rc2);
            u.rc1[0]='s';
            u.rc1[1]='e';
            u.rc1[2]='l';
            u.rc1[3]='f';
            u.rc1[4]='\n';
            u.rc1[5]='\0';
            u.rc2[0]='+';
            for(int i=0;i<100;i++)
            {
                if(addmoney[i]=='\n' || addmoney[i]=='\0')
                {
                    u.rc2[i+1]='\n';
                    u.rc2[i+2]='\0';
                    break;
                }
                u.rc2[i+1]=addmoney[i];
            }
         }
        //processing withdraw
        char remmoney[100];
        QString temp7=ui->withdrawbutton->text();
        char *str7=(char *)malloc(100);
        QByteArray ba7=temp7.toLatin1();
        strcpy(str7,ba7.data());
        if(temp7!=NULL)
        {
            for(int i=0;i<100;i++)
            {
                if(str7[i]=='\0' || str7[i]=='\n')
                {
                    remmoney[i]='\n';
                    remmoney[i+1]='\0';
                    break;
                }
                remmoney[i]=str7[i];
            }
            int remm;
            remm=stoi(remmoney);
            int curr;
            curr=stoi(u.acbal);
            curr=curr-remm;
            if(curr<0)
            {
                QMessageBox msgBox;
                msgBox.setText("Insufficient balance");
                msgBox.exec();
                curr=curr+remm;
            }
            sprintf(u.acbal, "%d", curr);
            if(u.n[0]=='0')
                u.n[0]='1';
            else if(u.n[0]=='1')
                u.n[0]='2';
            else if(u.n[0]=='2')
                u.n[0]='3';
            strcpy(u.rc5,u.rc3);
            strcpy(u.rc6,u.rc4);
            strcpy(u.rc3,u.rc1);
            strcpy(u.rc4,u.rc2);
            u.rc1[0]='s';
            u.rc1[1]='e';
            u.rc1[2]='l';
            u.rc1[3]='f';
            u.rc1[4]='\n';
            u.rc1[5]='\0';
            u.rc2[0]='-';
            for(int i=0;i<100;i++)
            {
                if(remmoney[i]=='\n' || remmoney[i]=='\0')
                {
                    u.rc2[i+1]='\n';
                    u.rc2[i+2]='\0';
                    break;
                }
                u.rc2[i+1]=remmoney[i];
            }
         }
        //processing other account transactions
        QString temp8=ui->otheraccountbutton->text();
        char *str8=(char *)malloc(100);
        QByteArray ba8=temp8.toLatin1();
        strcpy(str8,ba8.data());
        if(temp8!=NULL)
        {
            char str9[100]="C:\\BMS\\abcdefgh.txt\0";
            for(int i=0;i<8;i++)
            {
                str9[i+7]=str8[i];
            }
            FILE* f2;
            f2=fopen(str9,"r");
            if(f2==NULL)
            {
                QMessageBox msgBox;
                msgBox.setText("Invalid account number");
                msgBox.exec();
                return;
            }
            USER x;
            x.Retreive(f2);
            if(x.n[0]=='0')
                x.n[0]='1';
            else if(x.n[0]=='1')
                x.n[0]='2';
            else if(x.n[0]=='2')
                x.n[0]='3';
            strcpy(x.rc5,x.rc3);
            strcpy(x.rc6,x.rc4);
            strcpy(x.rc3,x.rc1);
            strcpy(x.rc4,x.rc2);
            for(int i=0;i<8;i++)
            {
                x.rc1[i]=address[i+7];
            }
            x.rc1[8]='\n';
            x.rc1[9]='\0';
            QString temp10=ui->transferamountbutton->text();
            char *str10=(char *)malloc(100);
            QByteArray ba10=temp10.toLatin1();
            strcpy(str10,ba10.data());
            x.rc2[0]='+';
            for(int i=0;i<100;i++)
            {
                if(str10[i]=='\n' || str10[i]=='\0')
                {
                    x.rc2[i+1]='\n';
                    x.rc2[i+2]='\0';
                    break;
                }
                x.rc2[i+1]=str10[i];
            }
            int m;
            m=stoi(str10);
            int curr;
            curr=stoi(u.acbal);
            curr=curr-m;
            if(curr<0)
            {
                QMessageBox msgBox;
                msgBox.setText("Insufficient balance");
                msgBox.exec();
                return;
            }
            sprintf(u.acbal,"%d",curr);
            int curr1;
            curr1=stoi(x.acbal);
            curr1=curr1+m;
            sprintf(x.acbal,"%d",curr1);
            for(int i=0;i<100;i++)
            {
                if(x.acbal[i]=='\n')
                {
                    x.acbal[i+1]='\0';
                    break;
                }
                if(x.acbal[i]=='\0')
                {
                    x.acbal[i]='\n';
                    x.acbal[i+1]='\0';
                    break;
                }
            }
            FILE* f4;
            f4=fopen(str9,"w");
            x.storeInFile(f4);
            fclose(f4);
            if(u.n[0]=='0')
                u.n[0]='1';
            else if(u.n[0]=='1')
                u.n[0]='2';
            else if(x.n[0]=='2')
                u.n[0]='3';
            strcpy(u.rc5,u.rc3);
            strcpy(u.rc6,u.rc4);
            strcpy(u.rc3,u.rc1);
            strcpy(u.rc4,u.rc2);
            strcpy(u.rc1,str8);
            u.rc1[8]='\n';
            u.rc1[9]='\0';
            u.rc2[0]='-';
            for(int i=1;i<100;i++)
            {
                u.rc2[i]=x.rc2[i];
                if(x.rc2[i]=='\0')
                    break;
            }
        }
        for(int i=0;i<100;i++)
        {
            if(u.acbal[i]=='\n')
            {
                u.acbal[i+1]='\0';
                break;
            }
            if(u.acbal[i]=='\0')
            {
                u.acbal[i]='\n';
                u.acbal[i+1]='\0';
                break;
            }
        }
    FILE* f1;
    f1=fopen(address,"w");
    u.storeInFile(f1);
    fclose(f1);
    displayuser(address);
}
//function to delete a account
void User::on_Delete_clicked()
{
    char pass[100];
    FILE* f;
    f=fopen(address,"r");
    fgets(pass,100,f);
    fclose(f);
    QString t= ui->currentpasswordbutton->text();
    char *p=(char *)malloc(100);
    QByteArray ba6=t.toLatin1();
    strcpy(p,ba6.data());
    bool match=true;
    for(int i=0;i<100;i++)
    {
        if((p[i]=='\0' || p[i]=='\n') && (pass[i]=='\0' || pass[i]=='\n'))
            break;
        if(pass[i]!=p[i])
        {
            match=false;
            break;
        }
    }
    if(match==false)
    {
        QMessageBox msgBox;
        msgBox.setText("Wrong password");
        msgBox.exec();
        return;
    }
    if(remove(address)!=0)
    {
        QMessageBox msgBox;
        msgBox.setText("Error deleting a/c");
        msgBox.exec();
        return;
    }
        QMessageBox msgBox;
        msgBox.setText("a/c deleted successfully");
        msgBox.exec();
    return;
}

#ifndef FORGOT_H
#define FORGOT_H

#include <QDialog>

namespace Ui {
class Forgot;
}

class Forgot : public QDialog
{
    Q_OBJECT

public:
    explicit Forgot(QWidget *parent = nullptr);
    ~Forgot();
public: void displayuser(char*);
private slots:
    void on_pushButton_clicked();

private:
    Ui::Forgot *ui;
    char address[100];
};

#endif // FORGOT_H

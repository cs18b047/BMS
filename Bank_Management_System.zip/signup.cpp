#include "signup.h"
#include "ui_signup.h"
#include <stdio.h>
#include <QMessageBox>
using namespace std;
signup::signup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::signup)
{
    ui->setupUi(this);
}

signup::~signup()
{
    delete ui;
}
class UserDetails
{
    public:
    char *phno,*vid,*mail,*name,*adhar;
    void storeInFile(FILE* &f2,char* latest)
    {
        fputs(latest,f2);
        fputs("\n",f2);
        fputs(phno,f2);
        fputs("\n",f2);
        fputs(mail,f2);
        fputs("\n",f2);
        fputs(vid,f2);
        fputs("\n",f2);
        fputs(adhar,f2);
        fputs("\n",f2);
        fputs(name,f2);
        fputs("\n",f2);
        fputs("0\n\0",f2);
        fputs("0\n\0",f2);
    }
};

void signup::on_pushButton_5_clicked()
{
    //accessing input information from ui
    QString phno=ui->Phonenumbutton->text();
    QString vid=ui->voteridbutton->text();
    QString mail=ui->emailbutton->text();
    QString name=ui->namebutton->text();
    QString adhar=ui->aadhaarbutton->text();
    UserDetails ob;
    //converting qstrings to character arrays
    ob.phno=(char *)malloc(100);
    QByteArray ba=phno.toLatin1();
    strcpy(ob.phno,ba.data());
    ob.vid=(char *)malloc(100);
    QByteArray ba1=vid.toLatin1();
    strcpy(ob.vid,ba1.data());
    ob.mail=(char *)malloc(100);
    QByteArray ba2=mail.toLatin1();
    strcpy(ob.mail,ba2.data());
    ob.name=(char *)malloc(100);
    QByteArray ba3=name.toLatin1();
    strcpy(ob.name,ba3.data());
    ob.adhar=(char *)malloc(100);
    QByteArray ba4=adhar.toLatin1();
    strcpy(ob.adhar,ba4.data());
    //accessing the lastest account number that is used
    FILE* f;
    f=fopen("C:\\BMS\\latest_ac.txt\0","r");
    char latest[10];
    fgets(latest,10,f);
    long int x=stoi(latest);
    x++;
    sprintf(latest, "%ld", x);
    fclose(f);
    //changing the latest account number
    FILE* f1;
    f1=fopen("C:\\BMS\\latest_ac.txt\0","w");
    fputs(latest,f1);
    fclose(f1);
    //creating a new txt file for storing the new user's information
    FILE* f2;
    char str[100]="C:\\BMS\\abcdefgh.txt\0";
    for(int i=0;i<8;i++)
    {
        str[i+7]=latest[i];
    }
    f2=fopen(str,"w");
    //storing the information in  txt file
    ob.storeInFile(f2,latest);
    QMessageBox msgBox;
    msgBox.setText(latest);
    msgBox.exec();
    return;
}
